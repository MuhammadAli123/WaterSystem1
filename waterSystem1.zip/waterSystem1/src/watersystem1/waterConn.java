package watersystem1;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import java.sql.SQLException;

public class waterConn {
    
    
    private Connection connShop = null;
    private Connection connHome = null;
    private Connection connOfficeIndus = null;
    
    public static Connection DB (){
    
        try{
         Class.forName("org.sqlite.JDBC");
         Connection connShop = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Ali\\Documents\\NetBeansProjects\\waterSystem1\\shop.sqlite");
         return connShop;         
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"connection failure");
            return null;
        }
     }

  }
