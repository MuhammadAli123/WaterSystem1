package watersystem1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class waterConn1 {

    private Connection connHome = null;
    
    public static Connection DB1 (){
    
      try{
           Class.forName("org.sqlite.JDBC");
           Connection connHome = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Ali\\Documents\\NetBeansProjects\\waterSystem1\\home.sqlite");
            return connHome;
        }
        catch(Exception e){
           JOptionPane.showMessageDialog(null,"connection failure");
           return null;
        } 
    
    
    }
}
