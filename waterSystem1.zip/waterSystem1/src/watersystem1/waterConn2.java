package watersystem1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class waterConn2 {
    
    private Connection connOfficeIndus = null;
    
    public static Connection DB2 (){
    
      try{
            Class.forName("org.sqlite.JDBC");
            Connection connOfficeIndus = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Ali\\Documents\\NetBeansProjects\\waterSystem1\\officeIndus.sqlite");
            return connOfficeIndus;
        }
        catch(Exception e){
           JOptionPane.showMessageDialog(null,"connection failure");
           return null;
        } 
    
    }
    
}
