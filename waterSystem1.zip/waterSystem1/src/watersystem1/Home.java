package watersystem1;


import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.event.KeyEvent;
import java.io.FileOutputStream;
import static java.lang.Thread.sleep;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import net.proteanit.sql.DbUtils;
//import watersystem1.Options;
//import watersystem1.waterConn;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ali
 */
public class Home extends javax.swing.JFrame {

    Connection connHome = null;
   ResultSet rsH = null;
   PreparedStatement pstHo = null;
    
    public Home() {
        initComponents();
        
        connHome = waterConn1.DB1();
        combox();
        CurrentDate();
    }

    public void Update_table(){

        try{
    String sql ="select * from  '"+HComboBox.getSelectedItem()+"' order by Sno";
    pstHo = connHome.prepareStatement(sql);
    rsH = pstHo.executeQuery();
    HomeTable.setModel(DbUtils.resultSetToTableModel(rsH));
        
        }
    catch(Exception e){

     JOptionPane.showMessageDialog(null, e);
    }
        finally{
        try{
         pstHo.close();
         rsH.close();
       }
        catch(Exception e){
        }
       }
        }
   
    public void combox(){
       
        try{
          String sql = "SELECT name FROM sqlite_master WHERE type='table'";
          
          pstHo = connHome.prepareStatement(sql);
          rsH = pstHo.executeQuery();
          
          while(rsH.next()){
             HComboBox.addItem(rsH.getString(1));
          }
        }
          catch(Exception e){
               JOptionPane.showMessageDialog(null, e);     
              }
        finally{
           try{
              pstHo.close();
              rsH.close();
             
           }
           catch(Exception e){
           }
        
        }
     }
    
   public void CurrentDate(){
         
           Thread clock = new Thread() {
           
             public void run(){
              
                  for(;;){
                 
                      try {
                          Calendar cal = new GregorianCalendar();
                          int month = cal.get(Calendar.MONTH);
                          int day   = cal.get(Calendar.DAY_OF_MONTH);
                          int year  = cal.get(Calendar.YEAR);
                          Date_txt.setText(" Date: "+day+"/"+(month+1)+"/"+year);
         
                          int sec  = cal.get(Calendar.SECOND);
                          int min  = cal.get(Calendar.MINUTE);
                          int hour = cal.get(Calendar.HOUR);
                          Time_txt.setText("  Time: "+hour+":"+min+":"+sec);
                          sleep(1000);
                      } catch (InterruptedException ex) {
                          Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
                      }
                 
                 }
              
             }
         
         };
            clock.start();
         }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        HComboBox = new javax.swing.JComboBox();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        HomeTable = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        Sno = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        date = new com.toedter.calendar.JDateChooser();
        jLabel4 = new javax.swing.JLabel();
        lit_19 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        BottleH = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        TotalBottle = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        lit_5_6 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        ml_500_600 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        Cbill = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        Tamount = new javax.swing.JTextField();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jLabel11 = new javax.swing.JLabel();
        Dreturn = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jToolBar1 = new javax.swing.JToolBar();
        Date_txt = new javax.swing.JLabel();
        Time_txt = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/watersystem1/res.PNG"))); // NOI18N
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        HComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "View Tables" }));
        HComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HComboBoxActionPerformed(evt);
            }
        });

        HomeTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        HomeTable.setRowHeight(25);
        HomeTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                HomeTableMouseClicked(evt);
            }
        });
        HomeTable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                HomeTableKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(HomeTable);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/watersystem1/de.PNG"))); // NOI18N
        jButton1.setText("Delete");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 887, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(58, 58, 58))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Table View", jPanel1);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("Serial no");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("Date");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Litre_19");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel5.setText("Bottle Received");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel6.setText("Bottles In Hand");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel7.setText("Litre_5_6");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel8.setText("ml_500_600");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel9.setText("Current Blll");

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel10.setText("Total Amount");

        Tamount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TamountActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setText("Bad");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setText("Average");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton3);
        jRadioButton3.setText("Good");
        jRadioButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton3ActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel11.setText("Damaged Return");

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/watersystem1/save.png"))); // NOI18N
        jButton2.setText("Save");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/watersystem1/up.PNG"))); // NOI18N
        jButton3.setText("Update");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/watersystem1/de.PNG"))); // NOI18N
        jButton4.setText("Delete");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton6.setText("Clear");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Cbill, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                        .addGap(395, 395, 395))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(18, 18, 18)
                                .addComponent(lit_5_6))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(26, 26, 26)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Sno, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                                    .addComponent(lit_19, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel8)))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(BottleH, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                                    .addComponent(ml_500_600, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                                    .addComponent(Tamount, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE))
                                .addGap(40, 40, 40)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel11))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Dreturn, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TotalBottle, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(114, 114, 114)
                                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(93, 93, 93)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jRadioButton1)
                                        .addGap(18, 18, 18)
                                        .addComponent(jRadioButton2)
                                        .addGap(18, 18, 18)
                                        .addComponent(jRadioButton3))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton3)))))))
                .addGap(26, 26, 26)
                .addComponent(jButton4)
                .addGap(42, 42, 42))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(96, 96, 96)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(Sno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3)))
                .addGap(42, 42, 42)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(lit_19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(BottleH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(TotalBottle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(lit_5_6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(ml_500_600, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(Dreturn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(Cbill, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(Tamount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton2)
                    .addComponent(jRadioButton3))
                .addGap(43, 43, 43)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(67, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Information Input", jPanel2);

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/watersystem1/PRI.PNG"))); // NOI18N
        jButton5.setText("Print");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/watersystem1/save.png"))); // NOI18N
        jButton8.setText("Save Report");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jToolBar1.setRollover(true);

        Date_txt.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Date_txt.setText("Date");
        jToolBar1.add(Date_txt);

        Time_txt.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Time_txt.setText("Time");
        jToolBar1.add(Time_txt);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(35, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 892, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(HComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(96, 96, 96)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(jButton8)))
                .addContainerGap(34, Short.MAX_VALUE))
            .addComponent(jToolBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(HComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)))
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 457, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton5)
                        .addGap(20, 20, 20))))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked

        dispose();
        Options op = new Options();
        op.setVisible(true);
    }//GEN-LAST:event_jLabel1MouseClicked

    private void HComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HComboBoxActionPerformed

        try{
            String sqlShop = "select * from '"+HComboBox.getSelectedItem()+"' ";
            pstHo = connHome.prepareStatement(sqlShop);
            rsH = pstHo.executeQuery();
             HomeTable.setModel(DbUtils.resultSetToTableModel(rsH));
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Proceed futher");
        }

        finally{
            try{
                pstHo.close();
                rsH.close();
            }
            catch(Exception e){
            }
        }
    }//GEN-LAST:event_HComboBoxActionPerformed

    private void HomeTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_HomeTableKeyReleased
        
         if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP){
            
                 try{
          int row = HomeTable.getSelectedRow();
          String table_clicked = (HomeTable.getModel().getValueAt(row, 0).toString());
          String sql = "select * from '"+HComboBox.getSelectedItem()+"' where Sno= '"+table_clicked+"' ";
          
          pstHo = connHome.prepareStatement(sql);
          rsH = pstHo.executeQuery();
          
          if(rsH.next()){
          
               String add1 =rsH.getString("Sno");
              Sno.setText(add1);
               java.util.Date add2 = rsH.getDate("Date");
              date.setDate(add2);   
               String add3 =rsH.getString("Lit_19");
              lit_19.setText(add3);
                String addv  = rsH.getString("BottleInHand");
                 BottleH.setText(addv);
               String add = rsH.getString("TotalInHand");
                TotalBottle.setText(add);
               String add4 =rsH.getString("Lit_5_6");
              lit_5_6.setText(add4);
               String add5 =rsH.getString("ml_500_600");
              ml_500_600.setText(add5);
               String add6 =rsH.getString("DamagedReturn");
              Dreturn.setText(add6);
               String add7 =rsH.getString("CurrentBill");
              Cbill.setText(add7);
              String add8 =rsH.getString("Totalamount");
              Tamount.setText(add8);
              boolean add9 =rsH.getBoolean("Status");
          /*    status.setSelected(add9); 
                status.setMnemonic(KeyEvent.VK_R);
              status.setActionCommand(add9);  */
          }
        
        }
         catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
        
        }
                    }
    }//GEN-LAST:event_HomeTableKeyReleased

    private void HomeTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HomeTableMouseClicked
        
              try{
          int row = HomeTable.getSelectedRow();
          String table_clicked = (HomeTable.getModel().getValueAt(row, 0).toString());
          String sql = "select * from '"+HComboBox.getSelectedItem()+"' where Sno= '"+table_clicked+"' ";
          
          pstHo = connHome.prepareStatement(sql);
          rsH = pstHo.executeQuery();
          
          if(rsH.next()){
          
               String add1 =rsH.getString("Sno");
              Sno.setText(add1);
              java.util.Date add2 = rsH.getDate("Date");
              date.setDate(add2);   
               String add3 =rsH.getString("lit_19");
              lit_19.setText(add3);
                String addv  = rsH.getString("BottleInHand");
                 BottleH.setText(addv);
               String add = rsH.getString("TotalInHand");
                TotalBottle.setText(add);
               String add4 =rsH.getString("lit_5_6");
              lit_5_6.setText(add4);
               String add5 =rsH.getString("ml_500_600");
              ml_500_600.setText(add5);
               String add6 =rsH.getString("DamagedReturn");
              Dreturn.setText(add6);
               String add7 =rsH.getString("Currentbill");
              Cbill.setText(add7);
              String add8 =rsH.getString("TotalAmount");
              Tamount.setText(add8);
              boolean add9 =rsH.getBoolean("status");
             // bad.setSelected(add9);
             // bad.setSelected(add9);
            
          }
        
        }
         catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
      //  Update_table();
        }
    }//GEN-LAST:event_HomeTableMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        int p = JOptionPane.showConfirmDialog(null,"Dp you really want to Delete","Deleted",JOptionPane.YES_NO_OPTION);
        
        try{
          String deleteShop = "Delete from '"+HComboBox.getSelectedItem()+"' where Sno=?";
          
          pstHo = connHome.prepareStatement(deleteShop);
          pstHo.setString(1,Sno.getText());
          pstHo.execute();
        }
        catch(Exception e){
          JOptionPane.showMessageDialog(null,e);
        }
        try{
           Update_table();
        }
        finally{
          try{
            pstHo.close();
            rsH.close();
          }
          catch(Exception e){
          }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void TamountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TamountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TamountActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
             try{
            
            String sqlsave = "insert into '"+HComboBox.getSelectedItem()+"'(Sno, Date, Lit_19, Lit_5_6, BottleInHand, TotalInHand, ml_500_600, DamagedReturn, CurrentBill, TotalAmount, Status) values(?,?,?,?,?,?,?,?,?,?,?)";
               pstHo = connHome.prepareStatement(sqlsave);
               
               pstHo.setString(1, Sno.getText());
               pstHo.setString(2,  ((JTextField)date.getDateEditor().getUiComponent()).getText());
               pstHo.setString(3, lit_19.getText());
               pstHo.setString(4, BottleH.getText());
               pstHo.setString(5, TotalBottle.getText());
               pstHo.setString(6, lit_5_6.getText());
               pstHo.setString(7, ml_500_600.getText());
               pstHo.setString(8, Dreturn.getText());
               pstHo.setString(9, Cbill.getText());
               pstHo.setString(10, Tamount.getText());
             //  if( String sql=" select from '"+SComboBox.getSelectedItem()+"' where status" == bad | average| good){
               pstHo.setString(11, statusHome);
             //  pst.setString(9, average.getText());
             //  pst.setString(9, good.getText());
              // pst.setString(10, Sno.getText());
           //    }
               pstHo.execute();
               JOptionPane.showMessageDialog(null , "Save");
               
            
        }
        catch(Exception e){
               JOptionPane.showMessageDialog(null , e );
            }
        try{
         Update_table(); 
        }
        finally{
          try{
            pstHo.close();
            rsH.close();
          }
          catch(Exception e){}
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
       statusHome = "Bad";
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
        statusHome = "Average";
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void jRadioButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton3ActionPerformed
        statusHome = "Good";
    }//GEN-LAST:event_jRadioButton3ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       
             try{
        
            String val1 = Sno.getText();
            String val2 =(((JTextField)date.getDateEditor().getUiComponent()).getText()); 
            String val3 = lit_19.getText();
            String val4 = BottleH.getText(); 
            String val5 = TotalBottle.getText();
            String val6 = lit_5_6.getText();
            String val7 = ml_500_600.getText();
            String val8 = Dreturn.getText();
            String val9 = Cbill.getText();
            String val10 = Tamount.getText();
            String val11 = statusHome;
  
            
            String updateShop = "update '"+HComboBox.getSelectedItem()+"' set Sno='"+val1+"', date='"+val2+"', Lit_19='"+val3+"', BottleInHand='"+val4+"', TotalInHand='"+val5+"', Lit_5_6='"+val6+"', ml_500_600='"+val7+"', DamagedReturn='"+val8+"', CurrentBill='"+val9+"', TotalAmount='"+val10+"', Status='"+val11+"' where Sno='"+val1+"' ";
            pstHo = connHome.prepareStatement(updateShop);
            pstHo.execute();
       }
        
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        try{
         Update_table(); 
        }
        finally{
          try{
            pstHo.close();
            rsH.close();
          }
          catch(Exception e){}
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        MessageFormat header = new MessageFormat(" '"+HComboBox.getSelectedItem()+"' Report");
        MessageFormat footer = new MessageFormat("Page{0,number,integer}");

        try{
           HomeTable.print(JTable.PrintMode.NORMAL, header, footer);
        }
        catch(java.awt.print.PrinterException e){
            System.err.format("Cannot print %s%n", e.getMessage());
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        
            int p = JOptionPane.showConfirmDialog(null,"Dp you really want to Delete","Deleted",JOptionPane.YES_NO_OPTION);
        
        try{
          String deleteShop = "Delete from '"+HComboBox.getSelectedItem()+"' where Sno=?";
          
          pstHo = connHome.prepareStatement(deleteShop);
          pstHo.setString(1,Sno.getText());
          pstHo.execute();
        }
        catch(Exception e){
          JOptionPane.showMessageDialog(null,e);
        }
        try{
           Update_table();
        }
        finally{
          try{
            pstHo.close();
            rsH.close();
          }
          catch(Exception e){
          }
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        
        Sno.setText("");
        date.setDate(null);
        lit_19.setText("");
        BottleH.setText("");
        TotalBottle.setText("");
        lit_5_6.setText("");
        ml_500_600.setText("");
        Dreturn.setText("");
        Cbill.setText("");
        Tamount.setText("");
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
       
         try{

            Document document = new Document();

            PdfWriter.getInstance(document,new FileOutputStream(" "+HComboBox.getSelectedItem()+".pdf"));
            document.open();
            //   Image image =  Image.getInstance("save.png");
            //     document.add(new Paragraph("image"));
            //    document.add(image);
            document.add(new Paragraph("ECHO TRADERS",FontFactory.getFont(FontFactory.TIMES_ROMAN,18,Font.BOLD,BaseColor.RED)));
            document.add(new Paragraph(" "+HComboBox.getSelectedItem()+" Report ",FontFactory.getFont(FontFactory.TIMES_ROMAN,18,Font.BOLD,BaseColor.BLUE)));
            document.add(new Paragraph(new java.util.Date().toString())) ;
            document.add(new Paragraph("--------------------------------------------------------"));
            PdfPTable table = new PdfPTable(11);
            PdfPCell cell= new PdfPCell (new Paragraph("Customer Report"));
            PdfPCell cell1= new PdfPCell (new Paragraph("Sno | Date | Lit19 | BottRec | TotBott | Lit_5/6 | ml500/600 | DamRet | CurBill | TotAmount | Status"));

            cell.setColspan(11);
            cell1.setColspan(11);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setBackgroundColor(BaseColor.GREEN);

            table.addCell(cell);

            cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell1.setBackgroundColor(BaseColor.ORANGE);
            table.addCell(cell1);
            String sql = "select * from '"+HComboBox.getSelectedItem()+"' ";
            pstHo = connHome.prepareStatement(sql);
            rsH = pstHo.executeQuery();
            while(rsH.next()){

                String v1 = rsH.getString("Sno");
                String add = rsH.getString("Date");
                String v2 = rsH.getString("Lit_19");
                String Bott = rsH.getString("BottleInHand");
                String ToBott = rsH.getString("TotalInHand");
                String v3 = rsH.getString("Lit_5_6");
                String v4 = rsH.getString("ml_500_600");
                String v5 =rsH.getString("DamagedReturn");
                String v6 =rsH.getString("CurrentBill");
                String v7 =rsH.getString("TotalAmount");
                String v8 =rsH.getString("Status");

                table.addCell(v1);
                table.addCell(add);
                table.addCell(v2);
                table.addCell(Bott);
                table.addCell(ToBott);
                table.addCell(v3);
                table.addCell(v4);
                table.addCell(v5);
                table.addCell(v6);
                table.addCell(v7);
                table.addCell(v8);
            }
            document.add(table);

            com.itextpdf.text.List list = new com.itextpdf.text.List(true,20);
            list.add("Printed Date:_____________");
            list.add("Signature:_______________");

            document.add(list);

            /*    MessageFormat footer1 = new MessageFormat("Page{0,number,integer}");
            com.itextpdf.text.List list2 = new com.itextpdf.text.List(true,20);
            //list2.print( footer1);
            document.add((Element) footer1);*/
            document.add(new Paragraph("----------------------------------------------------------------------"));
            document.add(new Paragraph("\r\r\r Circle",FontFactory.getFont(FontFactory.TIMES_ROMAN,12,Font.BOLD,BaseColor.BLUE)));
            document.add(new Paragraph(" Contact:",FontFactory.getFont(FontFactory.TIMES_ROMAN,12,Font.BOLD,BaseColor.BLUE)));
            document.add(new Paragraph(" Email:",FontFactory.getFont(FontFactory.TIMES_ROMAN,12,Font.BOLD,BaseColor.BLUE)));

            document.close();
            JOptionPane.showMessageDialog(null, "Saved Report");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField BottleH;
    private javax.swing.JTextField Cbill;
    private javax.swing.JLabel Date_txt;
    private javax.swing.JTextField Dreturn;
    private javax.swing.JComboBox HComboBox;
    private javax.swing.JTable HomeTable;
    private javax.swing.JTextField Sno;
    private javax.swing.JTextField Tamount;
    private javax.swing.JLabel Time_txt;
    private javax.swing.JTextField TotalBottle;
    private javax.swing.ButtonGroup buttonGroup1;
    private com.toedter.calendar.JDateChooser date;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JTextField lit_19;
    private javax.swing.JTextField lit_5_6;
    private javax.swing.JTextField ml_500_600;
    // End of variables declaration//GEN-END:variables

  private String statusHome;
}
